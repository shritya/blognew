
                <footer class="footer text-right">
                   Developed by: Shritej Kumbhar <span class="fa fa-crown"></span>
                </footer>
